package edu.ucr.cs.nle020.lucenesearcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LuceneSearcherApplication {

	public static void main(String[] args) {
		SpringApplication.run(LuceneSearcherApplication.class, args);
	}
}
